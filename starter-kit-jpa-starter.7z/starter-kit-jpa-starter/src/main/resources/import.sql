
insert into department (name_department, modification_counter) values ('Services', 1);
insert into department (name_department, modification_counter) values ('Human Resources', 1);
insert into department (name_department, modification_counter) values ('Marketiong',  1);
insert into department (name_department, modification_counter) values ('Sales', 1);
insert into department (name_department, modification_counter) values ('Legal', 'eng@wp.pl',1);

insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Melissa', 'Ruiz', '2633372465', '1987-06-21', 'ruiz@wp.pl', 76543212, 987654321, 1, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Karen', 'Austin', '4486308565', '1988-12-31', 'austin@wp.pl', 7898321, 98767421, 2, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Christopher', 'Perry', '9002499035', '1988-03-11', 'perry@wp.pl', 7654281, 9254321, 3, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Frank', 'Mills', '4639440839', '1985-05-03', 'millis@wp.pl', 73254321, 98532321, 4, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Daniel', 'Richardson', '59208638210', '1991-07-16', 'richardson@wp.pl', 7654091, 9876921, 5, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Daniel', 'Kowalski', '59208638510', '1992-05-11', 'kowalski@wp.pl', 7643218, 287654321, 5, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Mateusz', 'Malinowski', '48208638510', '1983-08-11', 'malinowski@wp.pl', 76549921, 987321, 1, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Mikolaj', 'Abski', '90208638510', '1983-10-19', 'abski@wp.pl', 769321, 9821321, 2, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Ilona', 'KFowalska', '88208638510', '1982-10-18', 'kfowalska@wp.pl', 7654321, 98234321, 3, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Monika', 'Kfrzyzanowska', '88298638510', '1975-10-11', 'kfrzyzanowska@wp.pl', 2254321, 99564321, 3, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Pawel', 'MiroFwski', '88207738510', '1992-10-18', 'miro@wp.pl', 7044321, 9872821, 2, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Michal', 'Jakubowski', '88907738510', '1998-10-18', 'jaku@wp.pl', 48743421, 438478321, 1, 1);
insert into employee (name_employee, surname_employee, pesel, birth_date, email_employee, home_phone_number_employee, mobile_phone_number_employee, id_department, modification_counter) values ('Jakub', 'Jakubowski', '88777738510', '1982-11-18', 'jakubowski@wp.pl', 765434521, 98654321, 2, 1);

insert into project (name_project, id_employee, type, modification_counter) values ('Tin', 1, 'internal', 1);
insert into project (name_project, id_employee, type, modification_counter) values ('Opela', 2, 'external', 1);
insert into project (name_project, id_employee, type, modification_counter) values ('Greenlam', 3, 'internal', 1);
insert into project (name_project, id_employee, type, modification_counter) values ('Voyatouch', 4, 'external', 1);
insert into project (name_project, id_employee, type, modification_counter) values ('Bigtax', 5, 'external', 1);

insert into employee_function (name_function, modification_counter) values ('pl', 1);
insert into employee_function (name_function, modification_counter) values ('tcd', 1);
insert into employee_function (name_function, modification_counter) values ('fcd', 1);
insert into employee_function (name_function, modification_counter) values ('dev', 1);

insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (22.34, '2013-09-19', '2016-05-23', 1, 1, 1, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (23.98, '2015-12-28', '2016-02-05', 2, 2, 2, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (45.80, '2009-06-05', '2012-08-20', 3, 3, 3, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (35.88, '2007-12-18', '2014-05-13', 4, 4, 4, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (30.37, '2012-06-13', '2016-02-22', 5, 4, 5, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (51.37, '2012-06-13', '2015-02-22', 5, 1, 2, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (30.00, '2008-06-13', '2009-02-22', 2, 4, 2, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (28.20, '2012-06-13', '2016-02-22', 1, 1, 3, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (25.30, '2012-06-13', '2014-03-10', 2, 3, 2, 1);
insert into project_data (reward, start_date, end_date, id_employee, id_employee_function, id_project, modification_counter) values (20.30, '2007-12-18', '2014-05-13', 4, 2, 4, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (30.00, '2012-06-13', 2, 3, 5, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (29.00, '2012-06-13', 2, 1, 2, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (51.37, '2010-06-13', 2, 3, 3, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (51.37, '2010-06-13', 3, 1, 3, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (21.37, '2010-06-13', 11, 2, 3, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (31.37, '2010-06-13', 11, 4, 3, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (31.37, '2010-06-13', 11, 4, 1, 1);
insert into project_data (reward, start_date, id_employee, id_employee_function, id_project, modification_counter) values (21.37, '2013-08-13', 13, 4, 1, 1);