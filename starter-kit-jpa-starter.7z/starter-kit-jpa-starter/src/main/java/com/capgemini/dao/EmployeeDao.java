package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.capgemini.domain.BookEntity;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;

public interface EmployeeDao extends Dao<EmployeeEntity, Long> {

	List<EmployeeEntity> findEmployeeByDepartment(Long id);

	EmployeeEntity findEmployeeByNameAndSurname(String nameEmployee, String surnameEmployee);

	List<ProjectDataEntity> findProjectDataByEmployeeIdAdnFunctionID(Long idEmployee, Long idFunction);

}
