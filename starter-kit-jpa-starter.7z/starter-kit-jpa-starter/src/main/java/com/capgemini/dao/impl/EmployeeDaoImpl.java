package com.capgemini.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;

@Repository
public class EmployeeDaoImpl extends AbstractDao<EmployeeEntity, Long> implements EmployeeDao {

	@Override
	public List<EmployeeEntity> findEmployeeByDepartment(Long id) {
		TypedQuery<EmployeeEntity> query = entityManager
				.createQuery("select employee from EmployeeEntity employee where id_department = :id",
						EmployeeEntity.class)
				.setParameter("id", id);
		return query.getResultList();
	}

	@Override
	public EmployeeEntity findEmployeeByNameAndSurname(String nameEmployee, String surnameEmployee) {
		TypedQuery<EmployeeEntity> query = entityManager
				.createQuery(
						"SELECT employee from EmployeeEntity employee where upper(name_employee) like concat(upper(:nameEmployee), '%') and upper(surname_employee) like concat(upper(:surnameEmployee), '%')",
						EmployeeEntity.class)
				.setParameter("nameEmployee", nameEmployee).setParameter("surnameEmployee", surnameEmployee);
		return query.getSingleResult();
	}

	@Override
	public List<ProjectDataEntity> findProjectDataByEmployeeIdAdnFunctionID(Long idEmployee, Long idFunction) {
		TypedQuery<ProjectDataEntity> query = entityManager
				.createQuery(
						"select project_data from ProjectDataEntity project_data where id_employee = :idEmployee and id_employee_function = :idFunction",
						ProjectDataEntity.class)
				.setParameter("idEmployee", idEmployee).setParameter("idFunction", idFunction);
		return query.getResultList();
	}

}
