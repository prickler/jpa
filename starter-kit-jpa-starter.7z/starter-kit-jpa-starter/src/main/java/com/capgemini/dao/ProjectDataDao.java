package com.capgemini.dao;

import java.math.BigInteger;
import java.util.List;

import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.domain.ProjectEntity;

public interface ProjectDataDao extends Dao<ProjectDataEntity, Long> {

	ProjectDataEntity findProjectByEmployeeId(Long idEmployee, Long idProject);

	List<EmployeeEntity> findActualEmployeeFromProject(Long idProject);

	List<ProjectDataEntity> findProjectDataByProjectId(Long idProject);

	List<BigInteger> findEmployeeByDate(int months, ProjectEntity project);

	List<ProjectDataEntity> findProjectDataByEmployeeId(Long idEmployee);

}
