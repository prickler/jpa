package com.capgemini.dao;

import com.capgemini.domain.EmployeeFunctionEntity;

public interface EmployeeFunctionDao  extends Dao <EmployeeFunctionEntity, Long>{

}
