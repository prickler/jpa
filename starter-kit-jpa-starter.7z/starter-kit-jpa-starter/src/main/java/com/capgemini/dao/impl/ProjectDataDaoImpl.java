package com.capgemini.dao.impl;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.dao.ProjectDataDao;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.domain.ProjectEntity;

@Repository
public class ProjectDataDaoImpl extends AbstractDao<ProjectDataEntity, Long> implements ProjectDataDao {

	@Override
	public ProjectDataEntity findProjectByEmployeeId(Long idEmployee, Long idProject) {
		TypedQuery<ProjectDataEntity> query = entityManager
				.createQuery(
						"select project_data from ProjectDataEntity project_data where id_employee = :idEmployee and id_project = :idProject",
						ProjectDataEntity.class)
				.setParameter("idEmployee", idEmployee).setParameter("idProject", idProject);
		return query.getSingleResult();
	}

	@Override
	public List<EmployeeEntity> findActualEmployeeFromProject(Long idProject) {
		TypedQuery<EmployeeEntity> query = entityManager.createQuery(
				"select employee from ProjectDataEntity project_data where id_project = :idProject and end_date = null",
				EmployeeEntity.class).setParameter("idProject", idProject);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BigInteger> findEmployeeByDate(int months, ProjectEntity project) {
		Query query = entityManager.createNativeQuery(
				"Select id_employee" 
				+ " from (select id_employee, sum(datediff((CASE WHEN end_date is NULL THEN NOW() ELSE end_date END), start_date))" 
				+ " AS days"
				+ " from project_data"
				+ " where id_project = :project"
			    + " group by id_employee, id_project) s"
			    + " where days > :time");
		query.setParameter("time", months * 30);
		query.setParameter("project", project.getIdProject());
		return query.getResultList();
	}  
	
	@Override
	public List<ProjectDataEntity> findProjectDataByProjectId(Long idProject) {
		TypedQuery<ProjectDataEntity> query = entityManager
				.createQuery(
						"select project_data from ProjectDataEntity project_data where id_project = :idProject",
						ProjectDataEntity.class)
				.setParameter("idProject", idProject);
		return query.getResultList();
	}
	
	@Override
	public List<ProjectDataEntity> findProjectDataByEmployeeId(Long idEmployee) {
		TypedQuery<ProjectDataEntity> query = entityManager
				.createQuery(
						"select project_data from ProjectDataEntity project_data where id_employee = :idEmployee",
						ProjectDataEntity.class)
				.setParameter("idEmployee", idEmployee);
		return query.getResultList();
	}

}

//select E.* from ProjectData pd inner join Employee E on E.id = pd.employee.id where timestampdiff (month, start_date, end_date)>=:months

