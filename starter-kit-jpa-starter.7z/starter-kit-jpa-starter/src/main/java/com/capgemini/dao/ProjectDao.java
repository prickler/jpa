package com.capgemini.dao;

import com.capgemini.domain.ProjectEntity;

public interface ProjectDao extends Dao<ProjectEntity, Long> {

}
