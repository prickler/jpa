package com.capgemini.dao;

import com.capgemini.domain.DepartmentEntity;

public interface DepartmentDao extends Dao <DepartmentEntity, Long> {

}
