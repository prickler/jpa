package com.capgemini.dao.impl;

import org.springframework.stereotype.Repository;

import com.capgemini.dao.EmployeeFunctionDao;
import com.capgemini.domain.EmployeeFunctionEntity;

@Repository
public class EmployeeFunctionDaoImpl extends AbstractDao<EmployeeFunctionEntity, Long> implements EmployeeFunctionDao{

}
