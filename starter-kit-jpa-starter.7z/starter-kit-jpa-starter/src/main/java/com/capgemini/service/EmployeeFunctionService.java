package com.capgemini.service;

import com.capgemini.domain.EmployeeFunctionEntity;

public interface EmployeeFunctionService {

	EmployeeFunctionEntity getOneFunction(Long idFunction);

}
