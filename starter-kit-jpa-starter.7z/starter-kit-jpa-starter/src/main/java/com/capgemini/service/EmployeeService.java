package com.capgemini.service;

import java.util.List;

import com.capgemini.domain.DepartmentEntity;
import com.capgemini.domain.EmployeeEntity;

public interface EmployeeService {
	
	List<EmployeeEntity> findEmployeeByDepartment(Long id);
	
	EmployeeEntity findEmployeeByNameAndSurname (String nameEmployee, String surnameEmployee);

	void deleteEmployee(EmployeeEntity employee);

	EmployeeEntity addEmployee(EmployeeEntity employee);
	
	EmployeeEntity updateNameEmployee (EmployeeEntity employee, String nameEmployee);

	EmployeeEntity updateDepartmentEmployee(EmployeeEntity employee, DepartmentEntity department);

	List<EmployeeEntity> findAllEmployee();

	EmployeeEntity getOneEmployee(Long idEmpoyee);

}
