package com.capgemini.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.EmployeeFunctionDao;
import com.capgemini.domain.EmployeeFunctionEntity;
import com.capgemini.service.EmployeeFunctionService;

@Service
public class EmployeeFunctionServiceImpl implements EmployeeFunctionService {

	@Autowired
	private EmployeeFunctionDao functionDao;

	@Override
	public EmployeeFunctionEntity getOneFunction(Long idFunction) {
		return functionDao.getOne(idFunction);
	}
}
