package com.capgemini.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.EmployeeFunctionDao;
import com.capgemini.domain.DepartmentEntity;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.service.EmployeeService;

@Service
@Transactional(readOnly = true)
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Autowired
	private EmployeeFunctionDao functionDao;

	@Override
	public EmployeeEntity addEmployee(EmployeeEntity employee) {
		return employeeDao.save(employee);
	}

	 @Override
	 public void deleteEmployee(EmployeeEntity employee) {
	 final long idFunction = 1;
	 if (checkIfIsNotProjectLeader(employee.getIdEmployee(), idFunction)) {
	 employeeDao.delete(employee);
	 }
	 else{
	 throw new IllegalArgumentException("This employee has role: PL");
	 }
	 }
	
	 private boolean checkIfIsNotProjectLeader(Long idEmployee, Long
	 idFunction) {
	 List<ProjectDataEntity> projectList =
	 employeeDao.findProjectDataByEmployeeIdAdnFunctionID(idEmployee,
	 idFunction);
	 return projectList.isEmpty();
	 }

	@Override
	public EmployeeEntity updateNameEmployee(EmployeeEntity employee, String nameEmployee) {
		employee.setNameEmployee(nameEmployee);
		return employeeDao.update(employee);
	}

	@Override
	public EmployeeEntity updateDepartmentEmployee(EmployeeEntity employee, DepartmentEntity department) {
		employee.setDepartment(department);
		return employeeDao.update(employee);
	}

	@Override
	public List<EmployeeEntity> findAllEmployee() {
		return employeeDao.findAll();
	}

	@Override
	public List<EmployeeEntity> findEmployeeByDepartment(Long id) {
		return employeeDao.findEmployeeByDepartment(id);
	}

	@Override
	public EmployeeEntity findEmployeeByNameAndSurname(String nameEmployee, String surnameEmployee) {
		return employeeDao.findEmployeeByNameAndSurname(nameEmployee, surnameEmployee);
	}

	@Override
	public EmployeeEntity getOneEmployee(Long idEmpoyee) {
		return employeeDao.getOne(idEmpoyee);
	}

}
