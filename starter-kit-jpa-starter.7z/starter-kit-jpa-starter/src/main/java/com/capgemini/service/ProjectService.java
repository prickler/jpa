package com.capgemini.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.domain.ProjectEntity;

public interface ProjectService {

	ProjectEntity addProject(ProjectEntity project);

	void deleteProject(ProjectEntity project);

	ProjectDataEntity addEmployeeToProject(ProjectDataEntity project);

	ProjectEntity updateProject(ProjectEntity project, String name);

	List<EmployeeEntity> findEmployeeFromProject(Long idProject);

	List<ProjectDataEntity> findAllProjectData();

	ProjectEntity getOneProject(Long idProject);

	List<ProjectEntity> findAllProject();

	List<ProjectDataEntity> findProjectDataByProjectId(Long idProject);

	void deleteEmployeeFromProject(Long idProject, Long idEmployee, LocalDate endDate);

	ProjectDataEntity findProjectDataByProjectIdAndEmployeeId(Long idProject, Long idEmployee);

	List<EmployeeEntity> findEmployeeByDate(int months, ProjectEntity project);

	List<ProjectDataEntity> findProjectDataByEmployeeId(Long idEmployee);

}
