package com.capgemini.service.impl;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.dao.ProjectDao;
import com.capgemini.dao.ProjectDataDao;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.domain.ProjectEntity;
import com.capgemini.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectDao projectDao;

	@Autowired
	private ProjectDataDao projectDataDao;
	
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public ProjectEntity addProject(ProjectEntity project) {
		return projectDao.save(project);
	}

	@Override
	public void deleteProject(ProjectEntity project) {
		List<ProjectDataEntity> projectDataList = projectDataDao.findProjectDataByProjectId(project.getIdProject());
		for (ProjectDataEntity projectData : projectDataList) {
			projectDataDao.delete(projectData);
		}
		projectDao.delete(project);
	}

	@Override
	public ProjectEntity updateProject(ProjectEntity project, String name) {
		if (projectDao.exists(project.getIdProject())) {
			project.setNameProject(name);
			return projectDao.update(project);
		} else {
			throw new IllegalArgumentException("Project does not exists");
		}
	}

	@Override
	public ProjectDataEntity addEmployeeToProject(ProjectDataEntity project) {
		return projectDataDao.save(project);
	}

	@Override
	public void deleteEmployeeFromProject(Long idProject, Long idEmployee, LocalDate endDate) {
		ProjectDataEntity entity = projectDataDao.findProjectByEmployeeId(idEmployee, idProject);
		entity.setEndDate(endDate);
	}

	@Override
	public List<ProjectDataEntity> findAllProjectData() {
		return projectDataDao.findAll();
	}

	@Override
	public List<ProjectEntity> findAllProject() {
		return projectDao.findAll();
	}

	@Override
	public List<EmployeeEntity> findEmployeeFromProject(Long idProject) {
		return projectDataDao.findActualEmployeeFromProject(idProject);
	}

	@Override
	public List<EmployeeEntity> findEmployeeByDate(int months, ProjectEntity project) {
		List<EmployeeEntity> employee = new ArrayList<EmployeeEntity>();
		List<BigInteger> foundEmployee = projectDataDao.findEmployeeByDate(months, project);
		for (BigInteger employeeFromProject : foundEmployee){
			employee.add(employeeDao.findOne(employeeFromProject.longValue()));
		}
		return employee;
	}

	@Override
	public ProjectEntity getOneProject(Long idProject){
		return projectDao.getOne(idProject);
	}

	@Override
	public List<ProjectDataEntity> findProjectDataByProjectId(Long idProject) {
		return projectDataDao.findProjectDataByProjectId(idProject);
	}

	@Override
	public ProjectDataEntity findProjectDataByProjectIdAndEmployeeId(Long idProject, Long idEmployee) {
		return projectDataDao.findProjectByEmployeeId(idEmployee, idProject);
	}
	
	@Override
	public List<ProjectDataEntity> findProjectDataByEmployeeId(Long idEmployee) {
		return projectDataDao.findProjectDataByEmployeeId(idEmployee);
	}
}
