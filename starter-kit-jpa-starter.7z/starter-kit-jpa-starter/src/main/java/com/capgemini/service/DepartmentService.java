package com.capgemini.service;

import com.capgemini.domain.DepartmentEntity;

public interface DepartmentService {

	DepartmentEntity findDepartmentById(Long idDepartment);

}
