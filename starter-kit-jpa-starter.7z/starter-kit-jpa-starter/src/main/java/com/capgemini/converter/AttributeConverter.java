package com.capgemini.converter;

public interface AttributeConverter<LocalDate, Date> {

	Date convertToDatabaseColumn(LocalDate locDate);

	LocalDate convertToEntityAttribute(Date sqlDate);

}
