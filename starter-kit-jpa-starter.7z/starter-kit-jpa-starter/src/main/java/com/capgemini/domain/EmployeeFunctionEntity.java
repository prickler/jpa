package com.capgemini.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "employeeFunction")
public class EmployeeFunctionEntity extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idEmployeeFunction;
	
	@NotNull
	@Column(unique = true)
	private String nameFunction;
	
	protected EmployeeFunctionEntity() {
	
	}

	public EmployeeFunctionEntity(int modificationCounter, String nameFunction) {

		this.modificationCounter = modificationCounter;
		this.nameFunction = nameFunction;
	}

	public Long getIdEmployeeFunction() {
		return idEmployeeFunction;
	}

	public void setIdEmployeeFunction(Long idEmployeeFunction) {
		this.idEmployeeFunction = idEmployeeFunction;
	}

	public String getNameFunction() {
		return nameFunction;
	}

	public void setNameFunction(String nameFunction) {
		this.nameFunction = nameFunction;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
