package com.capgemini.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Version;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@MappedSuperclass
public class AbstractEntity {

	@Version
	protected int modificationCounter;

	private Timestamp dateMajTech;

	private Timestamp dateCreaTech;

	public int getModificationCounter() {
		return modificationCounter;
	}

	@Column(name = "CREATION_TS", insertable = true, updatable = false)
	public Timestamp getDateCreaTech() {
		return dateCreaTech;
	}

	@Column(name = "UPDATE_TS", insertable = false, updatable = true)
	public Timestamp getDateMajTech() {
		return dateMajTech;
	}

	public void setDateCreaTech(Timestamp dateCreaTech) {
		this.dateCreaTech = dateCreaTech;
	}

	public void setDateMajTech(Timestamp dateMajTech) {
		this.dateMajTech = dateMajTech;
	}

	public void setModificationCounter(int modificationCounter) {
		this.modificationCounter = modificationCounter;
	}

	@PrePersist
	void onCreate() {
		this.setDateCreaTech(new Timestamp((new Date()).getTime()));
	}

	@PreUpdate
	void onPersist() {
		this.setDateMajTech(new Timestamp((new Date()).getTime()));
	}

}
