package com.capgemini.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "employee")
public class EmployeeEntity extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idEmployee;

	@NotNull
	@Column
	private String nameEmployee;

	@NotNull
	@Column
	private String surnameEmployee;

	@NotNull
	@Column(length = 11)
	private String pesel;

	@NotNull
	@Column
	private LocalDate birthDate;

	@NotNull
	@Column
	private String emailEmployee;

	@NotNull
	@Column(unique = true)
	private int homePhoneNumberEmployee;

	@NotNull
	@Column(unique = true)
	private int mobilePhoneNumberEmployee;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idDepartment")
	private DepartmentEntity department;

	protected EmployeeEntity() {

	}

	public EmployeeEntity(int modificationCounter, LocalDate birthDate, String emailEmployee,
			int homePhoneNumberEmployee, int mobilePhoneNumberEmployee, String nameEmployee, String pesel,
			String surnameEmployee, DepartmentEntity departmentId) {
	
		this.nameEmployee = nameEmployee;
		this.surnameEmployee = surnameEmployee;
		this.pesel = pesel;
		this.birthDate = birthDate;
		this.emailEmployee = emailEmployee;
		this.homePhoneNumberEmployee = homePhoneNumberEmployee;
		this.mobilePhoneNumberEmployee = mobilePhoneNumberEmployee;
		this.department = departmentId;
		this.modificationCounter = modificationCounter;
	}
	
	public DepartmentEntity getDepartment() {
		return department;
	}

	public void setDepartment(DepartmentEntity department) {
		this.department = department;
	}

	public Long getIdEmployee() {
		return idEmployee;
	}

	public void setIdEmployee(Long idEmployee) {
		this.idEmployee = idEmployee;
	}

	public String getNameEmployee() {
		return nameEmployee;
	}

	public void setNameEmployee(String nameEmployee) {
		this.nameEmployee = nameEmployee;
	}

	public String getSurnameEmployee() {
		return surnameEmployee;
	}

	public void setSurnameEmployee(String surnameEmployee) {
		this.surnameEmployee = surnameEmployee;
	}

	public String getPesel() {
		return pesel;
	}

	public void setPesel(String pesel) {
		this.pesel = pesel;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getEmailEmployee() {
		return emailEmployee;
	}

	public void setEmailEmployee(String emailEmployee) {
		this.emailEmployee = emailEmployee;
	}

	public int getHomePhoneNumberEmployee() {
		return homePhoneNumberEmployee;
	}

	public void setHomePhoneNumberEmployee(int homePhoneNumberEmployee) {
		this.homePhoneNumberEmployee = homePhoneNumberEmployee;
	}

	public int getMobilePhoneNumberEmployee() {
		return mobilePhoneNumberEmployee;
	}

	public void setMobilePhoneNumberEmployee(int mobilePhoneNumberEmployee) {
		this.mobilePhoneNumberEmployee = mobilePhoneNumberEmployee;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
