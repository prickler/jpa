package com.capgemini.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "projectData")
public class ProjectDataEntity extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idProjectData;

	@NotNull
	@Column
	private Double reward;

	@NotNull
	@Column
	private LocalDate startDate;

	@Column
	private LocalDate endDate;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idEmployee")
	private EmployeeEntity employee;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idEmployeeFunction")
	private EmployeeFunctionEntity employeeFunction;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "idProject")
	private ProjectEntity project;

	protected ProjectDataEntity() {

	}

	public ProjectDataEntity(int modificationCounter, LocalDate endDate, Double reward, LocalDate startDate,
			EmployeeFunctionEntity employeeFunction, EmployeeEntity employee, ProjectEntity project) {

		this.modificationCounter = modificationCounter;
		this.endDate = endDate;
		this.reward = reward;
		this.startDate = startDate;
		this.employeeFunction = employeeFunction;
		this.employee = employee;
		this.project = project;
	}

	public EmployeeEntity getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeEntity employee) {
		this.employee = employee;
	}

	public EmployeeFunctionEntity getEmployeeFunction() {
		return employeeFunction;
	}

	public void setEmployeeFunction(EmployeeFunctionEntity employeeFunction) {
		this.employeeFunction = employeeFunction;
	}

	public ProjectEntity getProject() {
		return project;
	}

	public void setProject(ProjectEntity project) {
		this.project = project;
	}

	public Long getIdProjectData() {
		return idProjectData;
	}

	public void setIdProjectData(Long idProjectData) {
		this.idProjectData = idProjectData;
	}

	public Double getReward() {
		return reward;
	}

	public void setReward(Double reward) {
		this.reward = reward;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
