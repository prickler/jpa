package com.capgemini.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.dao.EmployeeDao;
import com.capgemini.domain.DepartmentEntity;
import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.ProjectDataEntity;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class EmployeeServiceTest {

	final long ID_DEPARTMENT_1 = 1;
	final long ID_DEPARTMENT_2 = 2;
	final long ID_EMPLOYEE = 13;
	final String EXSISTS_NAME_EMPLOYEE = "Frank";
	final String EXSISTS_SURNAME_EMPLOYEE = "Mills";
	final String NEW_NAME_EMPLOYEE = "Ania";
	final String NEW_SURNAME_EMPLOYEE = "Szczypka";
	final String PESEL = "4639440839";
	final String EMAIL = "aa@gmail.com";
	final int MODIFICATION_COUNTER = 1;
	final int HOME_NUMBER = 9897654;
	final int MOBILE_NUMBER = 976567532;
	final LocalDate DATE = LocalDate.of(1992, 11, 19);
	final DepartmentEntity DEPARTMENT = null;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private ProjectService projectService;

	@Autowired
	private EmployeeDao dao;
	
	@Test
	public void testShouldfindAllEmployee() {
		// given
		// when
		List<EmployeeEntity> employeeList = employeeService.findAllEmployee();
		// then
		assertFalse(employeeList.isEmpty());
	}
	
	@Test
	public void testShouldAddEmployee() {
		// given
		int countBefore = employeeService.findAllEmployee().size();
		final EmployeeEntity employee = new EmployeeEntity(MODIFICATION_COUNTER, DATE, EMAIL, HOME_NUMBER,
				MOBILE_NUMBER, NEW_NAME_EMPLOYEE, PESEL, NEW_SURNAME_EMPLOYEE, DEPARTMENT);
		// when
		EmployeeEntity addEmployee = employeeService.addEmployee(employee);
		// then
		assertNotNull(addEmployee.getIdEmployee());
		assertEquals(countBefore + 1, employeeService.findAllEmployee().size());
	}
	
	@Test
	public void testShouldUpdateNameEmployee() {
		// given
		final EmployeeEntity employee = new EmployeeEntity(MODIFICATION_COUNTER, DATE, EMAIL, HOME_NUMBER,
				MOBILE_NUMBER, NEW_NAME_EMPLOYEE, PESEL, NEW_SURNAME_EMPLOYEE, DEPARTMENT);
		// when
		employeeService.addEmployee(employee);
		employeeService.updateNameEmployee(employee, "UpdateName");
		dao.flush();
		// then
		assertFalse(employee.getNameEmployee().isEmpty());
		assertEquals("UpdateName", employee.getNameEmployee());
		assertEquals(2, employee.getModificationCounter());
	}
	
	@Test
	public void testShouldUpdateDepartment() {
		// given
		final EmployeeEntity employee = new EmployeeEntity(MODIFICATION_COUNTER, DATE, EMAIL, HOME_NUMBER,
				MOBILE_NUMBER, NEW_NAME_EMPLOYEE, PESEL, NEW_SURNAME_EMPLOYEE, DEPARTMENT);
		// when
		employeeService.addEmployee(employee);
		DepartmentEntity departmentEntity = departmentService.findDepartmentById(ID_DEPARTMENT_2);
		employeeService.updateDepartmentEmployee(employee, departmentEntity);
		// then
		assertEquals(departmentEntity.getIdDepartment(), employee.getDepartment().getIdDepartment());
	}

	@Test
	public void shouldFindEmployeeByDeprtment() {
		// given
		// when
		List<EmployeeEntity> employee = employeeService.findEmployeeByDepartment(ID_DEPARTMENT_1);
		// then
		assertFalse(employee.isEmpty());
		assertEquals("Ruiz", employee.get(0).getSurnameEmployee());
		assertEquals("Malinowski", employee.get(1).getSurnameEmployee());
	}

	@Test
	public void shouldFindEmployeeByNameAndSurname() {
		// given
		// when
		EmployeeEntity employee = employeeService.findEmployeeByNameAndSurname(EXSISTS_NAME_EMPLOYEE,
				EXSISTS_SURNAME_EMPLOYEE);
		// then
		assertNotNull(employee);
		assertEquals("Frank", employee.getNameEmployee());
		assertEquals("Mills", employee.getSurnameEmployee());
	}

}
