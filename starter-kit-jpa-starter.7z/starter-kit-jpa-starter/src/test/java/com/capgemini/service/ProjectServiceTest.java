package com.capgemini.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.capgemini.domain.EmployeeEntity;
import com.capgemini.domain.EmployeeFunctionEntity;
import com.capgemini.domain.ProjectDataEntity;
import com.capgemini.domain.ProjectEntity;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class ProjectServiceTest {

	final LocalDate START_DATE = LocalDate.of(2014, 11, 19);
	final LocalDate END_DATE = LocalDate.of(2015, 11, 11);
	final int MODIFICATION_COUNTER = 1;
	final int MONTHS = 20;
	final double REWARD = 30.70;
	final long ID_EMPLOYEE = 2;
	final long ID_FUNCTION = 1;
	final long ID_PROJECT = 3;
	final long ID_PROJECT_DATA_1 = 3;
	final long ID_PROJECT_DATA_2 = 8;
	final String NAME_PROJECT = "starterkit";
	final String TYPE = "internal";

	@Autowired
	private ProjectService projectService;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmployeeFunctionService functionService;

	@Test
	public void testShouldfindAllProjectsData() {
		// given
		// when
		List<ProjectDataEntity> projectDataList = projectService.findAllProjectData();
		// then
		assertFalse(projectDataList.isEmpty());
	}

	@Test
	public void testShouldfindAllProjects() {
		// given
		// when
		List<ProjectEntity> projectList = projectService.findAllProject();
		// then
		assertFalse(projectList.isEmpty());
	}

	@Test
	public void shouldFindProjectDataByProjectId() {
		// given
		final ProjectEntity PROJECT = projectService.getOneProject(ID_PROJECT);
		// when
		List<ProjectDataEntity> projectData = projectService.findProjectDataByProjectId(ID_PROJECT);
		// then
		assertFalse(projectData.isEmpty());
		assertEquals(PROJECT.getIdProject(), projectData.get(0).getProject().getIdProject());
		assertEquals(PROJECT.getIdProject(), projectData.get(1).getProject().getIdProject());
	}

	@Test
	public void shouldFindProjectDataByProjectIdAndEmployeeId() {
		// given
		final ProjectEntity PROJECT = projectService.getOneProject(ID_PROJECT);
		final EmployeeEntity EMPLOYEE = employeeService.getOneEmployee(ID_EMPLOYEE);
		// when
		ProjectDataEntity projectData = projectService.findProjectDataByProjectIdAndEmployeeId(ID_PROJECT, ID_EMPLOYEE);
		// then
		assertEquals(PROJECT.getIdProject(), projectData.getProject().getIdProject());
		assertEquals(EMPLOYEE.getIdEmployee(), projectData.getEmployee().getIdEmployee());
	}

	@Test
	public void testShouldAddProject() {
		// given
		int countBefore = projectService.findAllProject().size();
		final EmployeeEntity EMPLOYEE = employeeService.getOneEmployee(ID_EMPLOYEE);
		final ProjectEntity project = new ProjectEntity(MODIFICATION_COUNTER, NAME_PROJECT, TYPE, EMPLOYEE);
		// when
		ProjectEntity addProject = projectService.addProject(project);
		// then
		assertNotNull(addProject.getIdProject());
		assertEquals(countBefore + 1, projectService.findAllProject().size());
	}

	@Test
	public void testShouldDeleteProject() {
		// given
		int countProjectDataBefore = projectService.findAllProjectData().size();
		int countProjectData = projectService.findProjectDataByProjectId(ID_PROJECT).size();
		int countProject = projectService.findAllProject().size();
		final ProjectEntity PROJECT = projectService.getOneProject(ID_PROJECT);
		// when
		projectService.deleteProject(PROJECT);
		// then
		assertEquals(countProjectDataBefore - countProjectData, projectService.findAllProjectData().size());
		assertEquals(countProject - 1, projectService.findAllProject().size());
	}

	@Test
	public void testShouldUpdateProject() {
		// given
		final ProjectEntity PROJECT = projectService.getOneProject(ID_PROJECT);
		// when
		projectService.updateProject(PROJECT, "test");
		// then
		assertFalse(PROJECT.getNameProject().isEmpty());
		assertEquals("test", PROJECT.getNameProject());
	}

	@Test
	public void testShouldAddEmployeeToProject() {
		// given
		int countBefore = projectService.findAllProjectData().size();
		final EmployeeEntity EMPLOYEE = employeeService.getOneEmployee(ID_EMPLOYEE);
		final EmployeeFunctionEntity FUNCTION = functionService.getOneFunction(ID_FUNCTION);
		final ProjectEntity PROJECT = projectService.getOneProject(ID_PROJECT);
		final ProjectDataEntity projectData = new ProjectDataEntity(MODIFICATION_COUNTER, END_DATE, REWARD, START_DATE,
				FUNCTION, EMPLOYEE, PROJECT);
		// when
		ProjectDataEntity addProjectData = projectService.addEmployeeToProject(projectData);
		// then
		assertNotNull(addProjectData.getIdProjectData());
		assertEquals(countBefore + 1, projectService.findAllProjectData().size());
	}

	@Test
	public void testShouldDeleteEmployeeFromProject() {
		// given
		// when
		projectService.deleteEmployeeFromProject(ID_PROJECT, ID_EMPLOYEE, END_DATE);
		// then
		assertEquals(END_DATE,
				projectService.findProjectDataByProjectIdAndEmployeeId(ID_PROJECT, ID_EMPLOYEE).getEndDate());
	}

	@Test
	public void shouldFindEmployeeFromProject() {
		// given
		// when
		List<EmployeeEntity> employee = projectService.findEmployeeFromProject(ID_PROJECT);
		// then
		assertFalse(employee.isEmpty());
		assertEquals("Austin", employee.get(0).getSurnameEmployee());
		assertEquals("Perry", employee.get(1).getSurnameEmployee());
	}

	@Test
	public void testShouldfindEmployeeByDate() {
		// given
		// when
		List<EmployeeEntity> employee = projectService.findEmployeeByDate(MONTHS,
				projectService.getOneProject(ID_PROJECT));
		// then
		assertFalse(employee.isEmpty());
		assertEquals("Ruiz", employee.get(0).getSurnameEmployee());
		assertEquals("Austin", employee.get(1).getSurnameEmployee());
	}

}